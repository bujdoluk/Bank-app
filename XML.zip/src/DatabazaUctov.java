import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class DatabazaUctov {

	public static void main(String[] args) {

		try {

			Document dokument = DocumentBuilderFactory.newDefaultInstance().newDocumentBuilder().newDocument();

			Element korenovyElement = dokument.createElement("bankoveUcty");
			dokument.appendChild(korenovyElement);

			Element ID = dokument.createElement("ID");
			korenovyElement.appendChild(ID);
			ID.setTextContent("a");

			Element meno = dokument.createElement("meno");
			korenovyElement.appendChild(meno);
			meno.setTextContent("a");

			Element priezvisko = dokument.createElement("priezvisko");
			korenovyElement.appendChild(priezvisko);
			priezvisko.setTextContent("a");

			Element rodneCislo = dokument.createElement("rodneCislo");
			korenovyElement.appendChild(rodneCislo);
			rodneCislo.setTextContent("a");

			Element zostatok = dokument.createElement("zostatok");
			korenovyElement.appendChild(zostatok);
			zostatok.setTextContent("a");

			Element heslo = dokument.createElement("heslo");
			korenovyElement.appendChild(heslo);
			heslo.setTextContent("a");

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");

			DOMSource zdroj = new DOMSource(dokument);
			StreamResult vysledok = new StreamResult("C:\\Users\\Dell\\eclipse-workspace\\MojProjekt\\src\\data5.xml");
			transformer.transform(zdroj, vysledok);

			// vystup na konzolu pre testovacie ucely
			StreamResult vystupNaKonzolu = new StreamResult(System.out);
			transformer.transform(zdroj, vystupNaKonzolu);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
